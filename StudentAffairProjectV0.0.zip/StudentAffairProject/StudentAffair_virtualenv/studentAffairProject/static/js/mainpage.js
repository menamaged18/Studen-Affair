// const procon = document.querySelector('.projects');
// const partcon = document.querySelector('.part')
// const smallTap = document.getElementById('.smallTap');
// const btn = document.getElementById('toggle-btn');
// const MEC = document.getElementById('.marginedited');
// // const nav = document.querySelector('nav');

// btn.onclick = function() {
//     // nav.classList.toggle('hide');
//     // if (partcon === null) {
//     // } else {
//     //     partcon.classList.toggle('expand');
//     // }
//     // if (smallTap === null) {
//     // } else {
//     //     smallTap.classList.toggle('expand');
//     // }
//     // if (procon === null) {
//     // } else {
//     //     procon.classList.toggle('expand');
//     // }
//     // if (MEC === null) {
//     // } else {
//     //     MEC.classList.toggle('expand');
//     // }
//     // partcon.classList.toggle('expand'); //error in all 
//     // smallTap.classList.toggle('expand'); //error in search 
//     // procon.classList.toggle('expand');
//     // MEC.classList.toggle('expand');
// };